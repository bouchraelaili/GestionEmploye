package Gestionemp;

public class EmpComission extends Employ� {
	int ventes;
    int Commission = 12*(10/100);
    
	    public EmpComission() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmpComission(double salaire,int ventes,int Commission) {
		super(salaire);
		this.ventes=ventes;
		this.Commission=Commission;
		
		// TODO Auto-generated constructor stub
	}

		


	    public void setSalaire(double salaire) {
	        this.salaire = salaire + (double) this.ventes *((double) Commission);
	    }

	    public int getVentes() {
	        return ventes;
	    }

	    public void setVentes(int ventes) {
	        this.ventes = ventes;
	    }

	    @Override
	    public void salaire() {
	        System.out.println("le salaire EmployeCommission est: " + getSalaire() + " avec " + ventes + " ventes");
	    }
}
