package Gestionemp;

public class EmpHoraire extends Employ� {
	
	int hours;
	
    public EmpHoraire() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmpHoraire(double salaire,int hours) {
		super(salaire);
		this.hours=hours;
		// TODO Auto-generated constructor stub
	}


    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public double getSalaire() {
        return salaire;
    }

    public void setSalaire(double salaire) {
        this.salaire = salaire * (double) this.hours;
    }

    @Override
    public void salaire(){
        System.out.println("le salaire EmployeeTauxHairaire est: " + this.salaire + " de " + hours + " hours");
    }
}
