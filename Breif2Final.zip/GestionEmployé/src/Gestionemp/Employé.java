package Gestionemp;

public abstract class Employ� {

	protected double salaire;


	public Employ�() {
		// TODO Auto-generated constructor stub
	}
	


	public Employ�(double salaire) {
		super();
		this.salaire = salaire;
	}



	public double getSalaire() {
		return salaire;
	}


	public void setSalaire(double salaire) {
		this.salaire = salaire;
	}
	
	public abstract void salaire();
}
