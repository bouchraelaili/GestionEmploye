package Gestionemp;

public class EmpFixe extends Employ� {

	    public EmpFixe(double salaire) {
		super(salaire);
		// TODO Auto-generated constructor stub
	}

		

	    public EmpFixe() {
			// TODO Auto-generated constructor stub
		}



		@Override
	    public void salaire() {
	        System.out.println("le salaire EmployeFixe est: " + getSalaire());
	    }

		
}
