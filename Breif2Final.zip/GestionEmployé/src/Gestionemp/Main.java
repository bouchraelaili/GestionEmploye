package Gestionemp;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmpFixe fixe = new EmpFixe();
        EmpComission Comission = new EmpComission();
        EmpHoraire Hours = new EmpHoraire();

        fixe.salaire = 100;
        fixe.salaire();


        Comission.setVentes(3);
        Comission.setSalaire(100);
        Comission.salaire();

        

        Hours.setHours(9);
        Hours.setSalaire(100);
        Hours.salaire();

		
	}

}
